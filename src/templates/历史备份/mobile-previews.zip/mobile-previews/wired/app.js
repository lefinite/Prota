// mobile-previews/wired — WIRED 快讯 · WIRED Design
// 保留：状态栏时间逻辑
// 页面：Tab 切换 / 文章筛选 / 按钮 Toast

const statusTime = document.getElementById("statusTime");
function updateStatusTime() {
  if (!statusTime) return;
  const now = new Date();
  statusTime.textContent = now.toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
}
updateStatusTime();
setInterval(updateStatusTime, 30000);

// Toast
const toastEl = document.getElementById("toast");
let toastTimer = null;
function showToast(msg) {
  if (!toastEl) return;
  toastEl.textContent = msg;
  toastEl.classList.add("is-show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastEl.classList.remove("is-show"), 1600);
}

// 任何带 data-toast 的按钮点击反馈
document.querySelectorAll("[data-toast]").forEach((el) => {
  el.addEventListener("click", () => showToast(el.dataset.toast));
});

// 底部 Tab 切换（仅本 Demo 的视觉高亮）
const tabs = document.querySelectorAll(".tabbar .tab");
tabs.forEach((tab) => {
  tab.addEventListener("click", () => {
    tabs.forEach((t) => t.classList.remove("is-active"));
    tab.classList.add("is-active");
    const label = tab.querySelector("span");
    showToast(label ? `${label.textContent.toUpperCase()}` : "SWITCHED");
  });
});

// 分类筛选
const chips = document.querySelectorAll("#filterChips .filter-chip");
const storyItems = document.querySelectorAll("#storyList .story-item");
chips.forEach((chip) => {
  chip.addEventListener("click", () => {
    chips.forEach((c) => {
      c.classList.remove("is-active");
      c.setAttribute("aria-selected", "false");
    });
    chip.classList.add("is-active");
    chip.setAttribute("aria-selected", "true");
    const filter = chip.dataset.filter;
    storyItems.forEach((item) => {
      const show = filter === "all" || item.dataset.type === filter;
      item.classList.toggle("is-hidden", !show);
    });
  });
});

// Newsletter 表单
const newsletterForm = document.querySelector(".newsletter-form");
const newsletterInput = document.querySelector(".newsletter-input");
const newsletterBtn = document.querySelector(".newsletter-btn");

if (newsletterBtn) {
  newsletterBtn.addEventListener("click", (e) => {
    e.preventDefault();
    if (newsletterInput && newsletterInput.value.trim()) {
      showToast("SUBSCRIBED");
      if (newsletterInput) newsletterInput.value = "";
    } else {
      showToast("ENTER EMAIL");
      if (newsletterInput) newsletterInput.focus();
    }
  });
}
